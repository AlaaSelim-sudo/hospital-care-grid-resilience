HOSPITAL CARE CONTINUITY UNDER FAULT-CONSTRAINED DISTRIBUTION RESTORATION
PESGM manuscript for author review, 11 November 2026

OPEN
  PESGM_Fault_Care_Paper.pdf: complete five-page paper, including references.
  Fault_Study_Supplement.pdf: full voltage/current maps, actual paired changes,
  capacity/restoration sensitivities and hospital/utility resource actions.
  Open_Paper.bat opens both. All research figures are editable native TikZ.
  The main manuscript includes the author list, demand-response motivation,
  and AI-use acknowledgment.

WHAT WAS ADDED
  Compound surge experiments add synchronized or staggered cohorts during
  delayed restoration. The severe case tests 12 h of isolation and sizes a
  common minimum fuel reserve for essential-only service. See README.md for
  exact case definitions, solver bounds and reproduction commands.
  A line-internal fault on 670--671 is simulated separately from the post-trip
  service problem. SLG and three-phase-ground snapshots use explicit resistances.
  Ideal protection isolates BOTH ends; no backfeed is closed onto a live fault.
  The post-trip MILP couples nonpreemptive care starts, critical-service
  availability, battery P/Q, generator fuel and an assumed temporary tie.
  Every accepted joint schedule is replayed using unbalanced AC power flow.
  Transformer and conductor CURRENT limits are now constraints, rather than
  being checked only after a voltage-only optimization.
  There is ONE IEEE-13 schematic, with the fault and new restoration tie.
  Absolute heatmaps use shared continuous colorbars with 0.95/100% markers.
  Differences use paired quarter-hour changes, averaged within each hour.
  Shared difference scales are +/-0.025 p.u. and +/-40 percentage points.
  No row normalization or clipped values. Open/isolated positions are gray.

OBSERVED / DERIVED / ASSUMED / SIMULATED
  Observed: Maine public residence-county total ED counts, original 32 TSV
  exports and source row IDs; EAGLE-I NH/VT/ME county snapshots. These are not
  DHMC/Copley arrivals, hospital meter outages or actual feeder fault records.
  Derived: recorded outage-hours, coverage, weekday estimates, exploratory
  same/next-day associations. Missing records stay unknown, not zero-filled.
  Assumed: 88/day hospital scale; within-day care classes/timing; ED load;
  equipment, fuel and rates; feeder locations, phase balancing, ratings,
  fault location/type/resistance, isolation/tie/repair times and source settings.
  Simulated: treatment scheduling, essential-service loss, costs, grid exchange,
  voltage and current responses. The network is a modified test feeder.
  Storm timing is the hour containing a retained county outage maximum,
  not a discovered hospital fault. Only Maine ratios drive the new demand
  cases; original NH/VT/ME county maps provide regional context.

INTERPRETATION
  Voltage-only restoration can still overload a transformer or line.
  Joint voltage/current constraints give electrically qualified schedules, but
  do not create fuel or capacity. April retains an essential-service deficit.
  A strong energy-first baseline with clinical tie-breaking reaches the same
  main-case timely coverage. No artificial objective-only improvement is claimed.
  Island hold changes the reconnection opportunity; it is a protocol
  counterfactual, not an algorithm-only comparison with identical topology.
  Local and voltage-only baselines can fail network constraints, so their
  nominal scheduled patient counts are not guaranteed deliverable care.
  Current-based planning limits do not simulate winding temperature, aging,
  protection selectivity, island dynamics or actual clinical harm.
  Critical availability is optimized first. Time-limited sensitivity patient
  incumbents are marked as such; solver logs retain bounds and gaps.

BENCHMARK MODIFICATIONS
  Main XFM1 rating is an assumed 600 kVA, tested at 500 and 650 kVA.
  H3 is behind the 634 low-voltage transformer; H1/H2 remain at 675/680.
  Native 634 phase loads are balanced at unchanged total 400 kW / 290 kvar
  under every policy. The same native daily background is used in all cases.
  Normally-open 633--680 tie: mtx601, 0.05 mile, assumed 500 A.
  Source conductor ampacities were absent. Every planning rating is explicit
  in Study_Assumptions.json and fault_network.py; defaults are not field data.
  Original_Reference_Audit preserves the earlier native XFM1 loading issue.
  Old and new global maxima cannot be compared as an intervention effect:
  the topology, phase balance and capacity scenarios changed explicitly.

FILES
  data/ED, ED_Download_Provenance.json, Observed_County_Daily_ED.csv:
    original public ED evidence and provenance.
  data/*EAGLEI*, extraction provenance, Source_Hashes.json:
    archived outage extracts and source integrity.
  Evidence_Daily.csv, Evidence_Correlations.csv:
    matched daily evidence and exploratory correlations.
  Fault_Design.json, Sensitivity_Design.json, Study_Assumptions.json:
    scenario definitions and observation/assumption boundary.
  Fault_Results.csv / Sensitivity_Results.csv:
    clinical, service, voltage/current and cost metrics.
  *_Time_Series.csv, *_Node_Voltages.csv, *_Current_Loading.csv:
    quarter-hour AC replay. Disconnected residual voltages are flagged
    unenergized and excluded by SOURCE REACHABILITY, not a voltage threshold.
    Voltage bases are recalculated after PCC topology changes.
  *_Treatment_Starts.csv:
    actual integer cohort choices, class, timing and duration.
  Fault_Snapshot_Results.csv:
    separate fault-on current/sag, with no sustained thermal interpretation.
  Plotted_Hourly_Heatmap_Cells.csv, Plotted_Hourly_Changes.csv:
    exact plot cells, including missing/open masks.
  Plotted_Resource_Dispatch.csv:
    per-site/hour grid, generator, battery, VAR, SOC, fuel and service values.
  solutions/*.npz + .json:
    saved decisions, guards, solver statuses, bounds and remaining gaps.
  cache/*.npz:
    saved AC references/sensitivities; trusted local NumPy object arrays.
  Study_Validation.json:
    source, cohort, service/resource reconstruction and selected AC checks.
  Document_Validation.json / Package_Hashes.json:
    PDF checks and SHA256 of packaged files.

REPRODUCTION
  Install Python 3.12+ packages with pip install -r requirements.txt.
  Install Tectonic on PATH; its first build may download TeX packages.
  Build_Paper.bat rebuilds native figures and both PDFs from saved CSVs.
  Run_Study.bat replays the retained solutions and performs data/model checks.
  Run_Study.bat --resolve requests fresh MILP solves and can take much longer.
  Fresh time-limited sensitivity incumbents can differ from the frozen release.
  --refine uses longer solve limits for unresolved/large-gap stages.
  Raw source files are frozen; the study does not need new data downloads.
  analyze_evidence.py rechecks the original TSV record IDs, source hashes,
  county/date matching, baselines and all county correlations.
  run_fault_study.py builds the cohort/resource MILP and phase constraints.
  fault_network.py implements topology and current bases.
  fault_snapshots.py runs the separate electrical fault diagnostics.
  validate_fault_study.py independently reconstructs care load, occupancy,
  energy, fuel and plot cells, and checks selected worst/boundary AC states.
  Same-engine verification is numerical validation, not field validation.

FUNDING
  The paper acknowledges support from the Irving Seed Fund.
